package com.mercadolibre.frontend


class MLHTMLContext extends HashMap<Object, Object> {
	
}
